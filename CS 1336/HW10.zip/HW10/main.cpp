#include <iostream>
#include <fstream>
#include <string>

using namespace std;

/*
	Purpose - Read text file with student record and display netID, major and GPA
	Author - Aashish Sharma
*/

int populateArrays(string fileName, int netIDArray[], string majorArray[], double gpaArray[], int size, int &records) // fill arrays with record from student file
{
	int i = 0;

	ifstream inputFile;
	inputFile.open(fileName); // open file

	if (inputFile) // parse through the input file
	{
		while (inputFile >> netIDArray[i] >> majorArray[i] >> gpaArray[i])
		{
			i++; // increase increment by 1
			records++; // increase record size by 1
		}
		inputFile.close(); // close file
		return 0;
	}
	else
	{
	    inputFile.close(); // close file
		return 1;
	}
}

int main()
{
    int size = 15;
    int record = 0;
	int netIDArray[15]; // net ID array
	string majorArray[15]; // major array
	double gpaArray[15]; // gpa array
	string fileName;
	int test = 0;

	cout << "Enter file name: "; // prompt user for file inpiut
	cin >> fileName;

	test = populateArrays(fileName, netIDArray, majorArray, gpaArray, size, record);
	if (test == 0) // call array
	{
        int printC = 0; // counter to print 3 records per line
        //display
        cout << "Number of records = " << record << endl;
        cout << "\n";
        cout << "******" << endl;
        cout << "Part 1" << endl;
        cout << "******" << endl;
        cout << "NetID array" << endl;
        cout << "-----------" << endl;
        for(int i = 0; i < record; i++)
        {
            if(printC < 3 && printC > 0) // add a comma after record if another record is going to follow it on the same line
            {
                cout << ", ";
            }
            if(printC == 3) // go to next line after 3 records have been displayed
            {
                cout << endl;
                printC = 0;
            }
            cout << "netIDArray[" << i << "] = " << netIDArray[i]; // print record
            printC++; // add one to print counter
        }

        printC = 0;
        cout << "\n";
        cout << "\n";
        cout << "Major array" << endl;
        cout << "-----------" << endl;
        for(int i = 0; i < record; i++)
        {
            if(printC < 3 && printC > 0) // add a comma after record if another record is going to follow it on the same line
            {
                cout << ", ";
            }
            if(printC == 3) // go to next line after 3 records have been displayed
            {
                cout << endl;
                printC = 0;
            }
            cout << "majorArray[" << i << "] = " << majorArray[i];
            printC++;
        }

        printC = 0;
        cout << "\n";
        cout << "\n";
        cout << "GPA array" << endl;
        cout << "---------" << endl;
        for(int i = 0; i < record; i++)
        {
            if(printC < 3 && printC > 0) // add a comma after record if another record is going to follow it on the same line
            {
                cout << ", ";
            }
            if(printC == 3) // go to next line after 3 records have been displayed
            {
                cout << endl;
                printC = 0;
            }
            cout << "gpaArray[" << i << "] = " << gpaArray[i];
            printC++;
        }
        // determine lowest gpa
        cout << "\n";
        cout << "\n";
        cout << "Lowest GPA" << endl;
        cout << "----------" << endl;
        double lowest;
        lowest = gpaArray[0];
        int Ltracker = 0;
        for(int i = 1; i < record; i++)
        {
            if(gpaArray[i] < lowest)
            {
                lowest = gpaArray[i];
            }
            if(gpaArray[i] == lowest)
            {
                Ltracker = i;
            }
        }
        cout << "NetID is " << netIDArray[Ltracker] << ", major is " << majorArray[Ltracker] << ", GPA = " << lowest << endl;
        // determine highest gpa
        cout << "\n";
        cout << "Highest GPA" << endl;
        cout << "-----------" << endl;
        // determine lowest GPA
        double highest;
        highest = gpaArray[0];
        int Htracker = 0;
        for(int i = 1; i < record; i++)
        {
            if(gpaArray[i] > highest)
            {
                highest = gpaArray[i];
            }
            if(gpaArray[i] == highest)
            {
                Htracker = i;
            }
        }
        cout << "NetID is " << netIDArray[Htracker] << ", major is " << majorArray[Htracker] << ", GPA = " << highest << endl;

        cout << "\n";
        cout << "Search on student's netID" << endl;
        cout << "-------------------------" << endl;
        int netID = 0;
        int choice = 1;

        while(choice != -1)
        {
            cout << "Input student's netID, -1 to quit: ";
            cin >> netID;
            int found = 0;
            if(netID == -1)
            {
                choice = netID;
            }
            else
            {
                int Ntracker = 0;
                for(int i = 0; i < record; i++)
                {
                    if(netIDArray[i] == netID)
                    {
                        Ntracker = i;
                        found = 1;
                    }
                }
                if(found == 1)
                {
                    cout << "NetID is " << netID << ", major is " << majorArray[Ntracker] << ", GPA = " << gpaArray[Ntracker] << endl;
                }
                else
                {
                    cout << "NetID not found" << endl;
                }
                cout << endl;
            }
        }

        cout << "******" << endl;
        cout << "Part 2" << endl;
        cout << "******" << endl;
        choice = 0;
        string major;
        double gpa;
        int i = record;
        while(choice != -1)
        {
            cout << "Enter netID, -1 if done: ";
            cin >> netID;
            if(netID == -1)
            {
                choice = netID;
            }
            else
            {
                cout << "Enter major then GPA: ";
                cin >> major >> gpa;
                netIDArray[i] = netID;
                majorArray[i] = major;
                gpaArray[i] = gpa;
                i++;
            }
            cout << endl;
        }

        cout << "\n";
        cout << "\n";
        cout << "--------------" << endl;
        cout << "Updated arrays" << endl;
        cout << "--------------" << endl;
        cout << "NetID array" << endl;
        cout << "-----------" << endl;
        printC = 0;
        for(int i = 0; i < 15; i++)
        {
            if(printC < 3 && printC > 0) // add a comma after record if another record is going to follow it on the same line
            {
                cout << ", ";
            }
            if(printC == 3) // go to next line after 3 records have been displayed
            {
                cout << endl;
                printC = 0;
            }
            cout << "netIDArray[" << i << "] = " << netIDArray[i]; // print record
            printC++; // add one to print counter
        }

        printC = 0;
        cout << "\n";
        cout << "\n";
        cout << "Major array" << endl;
        cout << "-----------" << endl;
        for(int i = 0; i < 15; i++)
        {
            if(printC < 3 && printC > 0) // add a comma after record if another record is going to follow it on the same line
            {
                cout << ", ";
            }
            if(printC == 3) // go to next line after 3 records have been displayed
            {
                cout << endl;
                printC = 0;
            }
            cout << "majorArray[" << i << "] = " << majorArray[i];
            printC++;
        }

        printC = 0;
        cout << "\n";
        cout << "\n";
        cout << "GPA array" << endl;
        cout << "---------" << endl;
        for(int i = 0; i < 15; i++)
        {
            if(printC < 3 && printC > 0) // add a comma after record if another record is going to follow it on the same line
            {
                cout << ", ";
            }
            if(printC == 3) // go to next line after 3 records have been displayed
            {
                cout << endl;
                printC = 0;
            }
            cout << "gpaArray[" << i << "] = " << gpaArray[i];
            printC++;
        }

        // CS statistics
        cout << "\n";
        cout << "CS statistics" << endl;
        cout << "-------------" << endl;
        int CScounter = 0;
        for(int i = 0; i < 15; i++)
        {
            if(majorArray[i] == "CS")
            {
                CScounter++;
            }
        }
        cout << "There are " << CScounter << " CS students" << endl;
        cout << "\n";
        lowest = gpaArray[1];
        for(int i = 1; i < 15; i++)
        {
            if(majorArray[i] == "CS")
            {
                if(gpaArray[i] < lowest)
                {
                    lowest = gpaArray[i];
                }
                if(gpaArray[i] == lowest)
                {
                    Ltracker = i;
                }
            }
        }
        cout << "Among all the CS students, the lowest GPA is " << lowest << endl;
        cout << "The CS student(s) with that GPA are: " << endl;
        cout << "NetID = " << netIDArray[Ltracker] << endl;
        cout << "\n";
        highest = gpaArray[1];
        for(int i = 1; i < 15; i++)
        {
            if(majorArray[i] == "CS")
            {
                if(gpaArray[i] > highest)
                {
                    highest = gpaArray[i];
                }
                if(gpaArray[i] == highest)
                {
                    Htracker = i;
                }
            }
        }
        cout << "Among all the CS students, the highest GPA is " << highest << endl;
        cout << "The CS student(s) with that GPA are: " << endl;
        cout << "NetID = " << netIDArray[Htracker];

	}
	else
	{
		cout << "Could not open file";
		exit(EXIT_FAILURE);
	}

	return 0;
}
